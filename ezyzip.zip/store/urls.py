# في ملف store/urls.py
# في ملف store/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('store.html', views.store, name='store'),
]
